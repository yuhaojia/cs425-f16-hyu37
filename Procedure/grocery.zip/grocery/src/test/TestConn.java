package test;

import conn.Conn;

public class TestConn {
	public static void main(String[] args){
		new Conn().getConn();
	}
}
